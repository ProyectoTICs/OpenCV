
// stdafx.cpp : source file that includes just the standard includes
// bgslibrary_vs2010_mfc.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"


